﻿namespace Figlut.Spread.Email
{
    public enum EmailProvider
    {
        GMail = 0
    }
}