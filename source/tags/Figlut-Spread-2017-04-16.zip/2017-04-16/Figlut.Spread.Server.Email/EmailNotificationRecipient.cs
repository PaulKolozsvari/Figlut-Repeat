﻿namespace Figlut.Spread.Email
{
    #region Using Directives

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    #endregion //Using Directives

    public class EmailNotificationRecipient
    {
        #region Properties

        public string EmailAddress { get; set; }

        public string DisplayName { get; set; }

        #endregion //Properties
    }
}
