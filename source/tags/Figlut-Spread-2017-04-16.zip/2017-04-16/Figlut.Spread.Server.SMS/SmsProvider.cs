﻿namespace Figlut.Spread.SMS
{
    public enum SmsProvider
    {
        Zoom = 0,
        Clickatell = 1
    }
}